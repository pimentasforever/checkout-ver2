import React from 'react';
import { Lock } from 'lucide-react';
import PaymentMethods from './checkout/PaymentMethods';
import OrderSummary from './checkout/OrderSummary';
import SecurityBadges from './checkout/SecurityBadges';
import Timer from './checkout/Timer';

const CheckoutForm = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-6xl mx-auto px-4 py-12">
        <div className="flex justify-center items-center mb-8 animate-fade-in">
          <Lock className="w-5 h-5 text-green-500 mr-2" />
          <span className="text-sm text-gray-600">Pagamento 100% Seguro</span>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="order-2 lg:order-1">
            <PaymentMethods />
          </div>
          
          <div className="order-1 lg:order-2">
            <OrderSummary />
            <Timer />
          </div>
        </div>
        
        <SecurityBadges />
      </div>
    </div>
  );
};

export default CheckoutForm;
import React from 'react';
import { Shield, Lock, CreditCard } from 'lucide-react';

const SecurityBadges = () => {
  return (
    <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
      <div className="p-4">
        <Shield className="w-8 h-8 mx-auto text-gray-600 mb-2" />
        <h3 className="font-semibold mb-1">Compra Segura</h3>
        <p className="text-sm text-gray-500">Site protegido e verificado</p>
      </div>
      
      <div className="p-4">
        <Lock className="w-8 h-8 mx-auto text-gray-600 mb-2" />
        <h3 className="font-semibold mb-1">Privacidade Protegida</h3>
        <p className="text-sm text-gray-500">Seus dados estão seguros</p>
      </div>
      
      <div className="p-4">
        <CreditCard className="w-8 h-8 mx-auto text-gray-600 mb-2" />
        <h3 className="font-semibold mb-1">Pagamento Processado</h3>
        <p className="text-sm text-gray-500">pela maior gateway do Brasil</p>
      </div>
    </div>
  );
};

export default SecurityBadges;
import React from 'react';
import { CheckCircle } from 'lucide-react';

const OrderSummary = () => {
  return (
    <div className="bg-white p-6 rounded-lg shadow-md mb-6">
      <h2 className="text-2xl font-bold mb-6">Resumo do Pedido</h2>
      
      <div className="space-y-4 mb-6">
        <div className="flex items-start">
          <img
            src="https://images.unsplash.com/photo-1499750310107-5fef28a66643"
            alt="Curso"
            className="w-20 h-20 object-cover rounded-lg"
          />
          <div className="ml-4">
            <h3 className="font-semibold">Curso Completo de Marketing Digital</h3>
            <p className="text-gray-500">Acesso vitalício</p>
          </div>
        </div>

        <div className="border-t border-b border-gray-200 py-4">
          <div className="flex justify-between mb-2">
            <span>Valor original</span>
            <span className="line-through text-gray-500">R$ 997,00</span>
          </div>
          <div className="flex justify-between mb-2">
            <span>Desconto</span>
            <span className="text-green-500">- R$ 500,00</span>
          </div>
          <div className="flex justify-between font-bold">
            <span>Total</span>
            <span className="text-2xl">R$ 497,00</span>
          </div>
          <div className="text-sm text-gray-500 mt-2">
            ou 12x de R$ 41,42 sem juros
          </div>
        </div>
      </div>

      <button className="w-full bg-green-500 hover:bg-green-600 text-white font-bold py-4 px-6 rounded-lg transition-colors">
        GARANTIR MINHA VAGA AGORA
      </button>

      <div className="mt-4 space-y-2">
        <div className="flex items-center text-sm text-gray-600">
          <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
          <span>7 dias de garantia incondicional</span>
        </div>
        <div className="flex items-center text-sm text-gray-600">
          <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
          <span>Acesso imediato ao conteúdo</span>
        </div>
      </div>
    </div>
  );
};

export default OrderSummary;
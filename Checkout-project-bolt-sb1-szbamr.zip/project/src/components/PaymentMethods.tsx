import React, { useState } from 'react';
import { CreditCard, QrCode, Barcode } from 'lucide-react';

const PaymentMethods = () => {
  const [selectedMethod, setSelectedMethod] = useState('credit');

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-2xl font-bold mb-6">Forma de Pagamento</h2>
      
      <div className="space-y-4">
        <button
          className={`w-full p-4 rounded-lg border ${
            selectedMethod === 'credit'
              ? 'border-purple-500 bg-purple-50'
              : 'border-gray-200'
          } flex items-center`}
          onClick={() => setSelectedMethod('credit')}
        >
          <CreditCard className="w-6 h-6 text-purple-600 mr-3" />
          <div className="text-left">
            <p className="font-semibold">Cartão de Crédito</p>
            <p className="text-sm text-gray-500">Até 12x sem juros</p>
          </div>
        </button>

        <button
          className={`w-full p-4 rounded-lg border ${
            selectedMethod === 'pix'
              ? 'border-purple-500 bg-purple-50'
              : 'border-gray-200'
          } flex items-center`}
          onClick={() => setSelectedMethod('pix')}
        >
          <QrCode className="w-6 h-6 text-purple-600 mr-3" />
          <div className="text-left">
            <p className="font-semibold">PIX</p>
            <p className="text-sm text-gray-500">15% de desconto</p>
          </div>
        </button>

        <button
          className={`w-full p-4 rounded-lg border ${
            selectedMethod === 'boleto'
              ? 'border-purple-500 bg-purple-50'
              : 'border-gray-200'
          } flex items-center`}
          onClick={() => setSelectedMethod('boleto')}
        >
          <Barcode className="w-6 h-6 text-purple-600 mr-3" />
          <div className="text-left">
            <p className="font-semibold">Boleto Bancário</p>
            <p className="text-sm text-gray-500">10% de desconto</p>
          </div>
        </button>
      </div>

      {selectedMethod === 'credit' && (
        <div className="mt-6 space-y-4">
          <input
            type="text"
            placeholder="Número do Cartão"
            className="w-full p-3 border border-gray-300 rounded-lg"
          />
          <div className="grid grid-cols-2 gap-4">
            <input
              type="text"
              placeholder="Validade"
              className="p-3 border border-gray-300 rounded-lg"
            />
            <input
              type="text"
              placeholder="CVV"
              className="p-3 border border-gray-300 rounded-lg"
            />
          </div>
          <input
            type="text"
            placeholder="Nome no Cartão"
            className="w-full p-3 border border-gray-300 rounded-lg"
          />
        </div>
      )}
    </div>
  );
};

export default PaymentMethods;
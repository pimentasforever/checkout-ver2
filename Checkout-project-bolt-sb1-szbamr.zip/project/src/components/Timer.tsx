import React, { useState, useEffect } from 'react';
import { Clock } from 'lucide-react';

const Timer = () => {
  const [timeLeft, setTimeLeft] = useState({
    minutes: 15,
    seconds: 0,
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev.seconds === 0) {
          if (prev.minutes === 0) {
            clearInterval(timer);
            return prev;
          }
          return {
            minutes: prev.minutes - 1,
            seconds: 59,
          };
        }
        return {
          ...prev,
          seconds: prev.seconds - 1,
        };
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  return (
    <div className="bg-red-50 border border-red-100 p-4 rounded-lg text-center">
      <div className="flex items-center justify-center mb-2">
        <Clock className="w-5 h-5 text-red-500 mr-2" />
        <span className="text-red-500 font-semibold">Oferta por tempo limitado!</span>
      </div>
      <div className="text-2xl font-bold text-red-600">
        {String(timeLeft.minutes).padStart(2, '0')}:
        {String(timeLeft.seconds).padStart(2, '0')}
      </div>
    </div>
  );
};

export default Timer;
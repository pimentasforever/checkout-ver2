import React from 'react';
import { CheckCircle2 } from 'lucide-react';
import Card from '../ui/Card';
import Button from '../ui/Button';

const OrderSummary = () => {
  return (
    <Card className="p-8">
      <h2 className="text-2xl font-semibold text-gray-900 mb-6">Resumo do Pedido</h2>
      
      <div className="space-y-6">
        <div className="flex items-start animate-fade-in">
          <img
            src="https://images.unsplash.com/photo-1499750310107-5fef28a66643"
            alt="Curso"
            className="w-24 h-24 object-cover rounded-xl"
          />
          <div className="ml-4">
            <h3 className="font-medium text-gray-900">Curso Completo de Marketing Digital</h3>
            <p className="text-gray-500 text-sm">Acesso vitalício</p>
          </div>
        </div>

        <div className="space-y-3 py-6 border-t border-b border-gray-100">
          <div className="flex justify-between text-sm">
            <span className="text-gray-500">Valor original</span>
            <span className="line-through text-gray-400">R$ 997,00</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-gray-500">Desconto</span>
            <span className="text-green-500">- R$ 500,00</span>
          </div>
          <div className="flex justify-between items-end pt-2">
            <span className="text-gray-900 font-medium">Total</span>
            <div className="text-right">
              <span className="text-3xl font-semibold">R$ 497,00</span>
              <p className="text-sm text-gray-500 mt-1">ou 12x de R$ 41,42 sem juros</p>
            </div>
          </div>
        </div>

        <Button fullWidth>
          Garantir minha vaga agora
        </Button>

        <div className="space-y-3">
          <div className="flex items-center text-sm text-gray-600">
            <CheckCircle2 className="w-5 h-5 text-green-500 mr-2" />
            <span>7 dias de garantia incondicional</span>
          </div>
          <div className="flex items-center text-sm text-gray-600">
            <CheckCircle2 className="w-5 h-5 text-green-500 mr-2" />
            <span>Acesso imediato ao conteúdo</span>
          </div>
        </div>
      </div>
    </Card>
  );
};

export default OrderSummary;
import React, { useState, useEffect } from 'react';
import { Clock } from 'lucide-react';
import Card from '../ui/Card';

const Timer = () => {
  const [timeLeft, setTimeLeft] = useState({
    minutes: 15,
    seconds: 0,
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev.seconds === 0) {
          if (prev.minutes === 0) {
            clearInterval(timer);
            return prev;
          }
          return {
            minutes: prev.minutes - 1,
            seconds: 59,
          };
        }
        return {
          ...prev,
          seconds: prev.seconds - 1,
        };
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  return (
    <Card className="mt-6 bg-gradient-to-r from-red-50 to-orange-50 border-none">
      <div className="p-6 text-center animate-pulse">
        <div className="flex items-center justify-center mb-2">
          <Clock className="w-5 h-5 text-red-500 mr-2" />
          <span className="text-red-500 font-medium">Oferta por tempo limitado</span>
        </div>
        <div className="text-3xl font-semibold text-red-600 tracking-wider">
          {String(timeLeft.minutes).padStart(2, '0')}:
          {String(timeLeft.seconds).padStart(2, '0')}
        </div>
      </div>
    </Card>
  );
};

export default Timer;
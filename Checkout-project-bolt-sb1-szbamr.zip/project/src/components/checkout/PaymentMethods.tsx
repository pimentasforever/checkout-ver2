import React, { useState } from 'react';
import { CreditCard, QrCode, Barcode } from 'lucide-react';
import Card from '../ui/Card';
import Button from '../ui/Button';

const PaymentMethods = () => {
  const [selectedMethod, setSelectedMethod] = useState('credit');

  const methods = [
    {
      id: 'credit',
      icon: CreditCard,
      title: 'Cartão de Crédito',
      description: 'Até 12x sem juros',
    },
    {
      id: 'pix',
      icon: QrCode,
      title: 'PIX',
      description: '15% de desconto',
    },
    {
      id: 'boleto',
      icon: Barcode,
      title: 'Boleto Bancário',
      description: '10% de desconto',
    },
  ];

  return (
    <Card className="p-8">
      <h2 className="text-2xl font-semibold text-gray-900 mb-6">Forma de Pagamento</h2>
      
      <div className="space-y-3">
        {methods.map((method) => (
          <button
            key={method.id}
            className={`w-full p-4 rounded-xl border-2 transition-all duration-200 ${
              selectedMethod === method.id
                ? 'border-black bg-gray-50'
                : 'border-gray-100 hover:border-gray-200'
            } flex items-center group animate-fade-in`}
            onClick={() => setSelectedMethod(method.id)}
          >
            <method.icon className={`w-6 h-6 ${
              selectedMethod === method.id ? 'text-black' : 'text-gray-400'
            } group-hover:text-black transition-colors mr-4`} />
            <div className="text-left">
              <p className="font-medium text-gray-900">{method.title}</p>
              <p className="text-sm text-gray-500">{method.description}</p>
            </div>
          </button>
        ))}
      </div>

      {selectedMethod === 'credit' && (
        <div className="mt-8 space-y-4 animate-fade-in">
          <input
            type="text"
            placeholder="Número do Cartão"
            className="w-full p-4 border border-gray-200 rounded-xl focus:border-black focus:ring-1 focus:ring-black transition-colors"
          />
          <div className="grid grid-cols-2 gap-4">
            <input
              type="text"
              placeholder="Validade"
              className="p-4 border border-gray-200 rounded-xl focus:border-black focus:ring-1 focus:ring-black transition-colors"
            />
            <input
              type="text"
              placeholder="CVV"
              className="p-4 border border-gray-200 rounded-xl focus:border-black focus:ring-1 focus:ring-black transition-colors"
            />
          </div>
          <input
            type="text"
            placeholder="Nome no Cartão"
            className="w-full p-4 border border-gray-200 rounded-xl focus:border-black focus:ring-1 focus:ring-black transition-colors"
          />
        </div>
      )}
    </Card>
  );
};

export default PaymentMethods;
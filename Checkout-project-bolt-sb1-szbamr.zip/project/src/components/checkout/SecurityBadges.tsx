import React from 'react';
import { Shield, Lock, CreditCard } from 'lucide-react';

const SecurityBadges = () => {
  const badges = [
    {
      icon: Shield,
      title: 'Compra Segura',
      description: 'Site protegido e verificado',
    },
    {
      icon: Lock,
      title: 'Privacidade Protegida',
      description: 'Seus dados estão seguros',
    },
    {
      icon: CreditCard,
      title: 'Pagamento Processado',
      description: 'pela maior gateway do Brasil',
    },
  ];

  return (
    <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-8">
      {badges.map((badge, index) => (
        <div
          key={index}
          className="flex flex-col items-center text-center animate-fade-in"
          style={{ animationDelay: `${index * 100}ms` }}
        >
          <badge.icon className="w-8 h-8 text-gray-400 mb-3" />
          <h3 className="font-medium text-gray-900 mb-1">{badge.title}</h3>
          <p className="text-sm text-gray-500">{badge.description}</p>
        </div>
      ))}
    </div>
  );
};

export default SecurityBadges;
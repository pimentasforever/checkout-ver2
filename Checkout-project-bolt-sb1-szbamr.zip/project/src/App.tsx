import React from 'react';
import CheckoutForm from './components/CheckoutForm';
import './styles/animations.css';

function App() {
  return (
    <div className="bg-gray-50">
      <CheckoutForm />
    </div>
  );
}

export default App;